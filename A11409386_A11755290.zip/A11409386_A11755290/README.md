# CSE131

Describe briefly how you approached the project in Project_Description.txt 

Fill in the name email and pid in the script submission.sh 
Execute the script like 

$ ./submission.sh 

if it fails to execute then try changing the permissions like 
$ chmod +x submission.sh 

if it fails for other reasons, then fix the name,email, pid etc whatever the error message says.


After it executes, you would get a zip file which you need to submit on the link given in piazza submission guildelines.
